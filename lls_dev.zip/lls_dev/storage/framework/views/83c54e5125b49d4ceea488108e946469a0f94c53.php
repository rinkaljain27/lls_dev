<?php $__env->startSection('title', __('Page Not Found')); ?>
<?php $__env->startSection('code', '404'); ?>
<?php $__env->startSection('message', __('Page Not Found')); ?>
<?php $__env->startSection('ext_message', __('Sorry, we can’t find the page you were looking for.')); ?>
<?php echo $__env->make('errors::minimal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\lls_dev\resources\views/errors/404.blade.php ENDPATH**/ ?>