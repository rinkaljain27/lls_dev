<nav class="sidebar sidebar-offcanvas" id="sidebar">
  <div class="sidebar-brand-wrapper d-none d-lg-flex align-items-center justify-content-center fixed-top">
    <a class="sidebar-brand brand-logo" href="<?php echo e(route('home')); ?>"><img src="<?php echo URL::to('assets\images\logo.svg'); ?> " alt="logo" /></a>
    <a class="sidebar-brand brand-logo-mini" href="<?php echo e(route('home')); ?>"><img src="<?php echo URL::to('assets\images\logo-mini.svg'); ?>" alt="logo" /></a>
  </div>
  <ul class="nav">
    
    <li class="nav-item menu-items">
      <a class="nav-link" href="<?php echo e(route('home')); ?>">
        <span class="menu-icon">
          <i class="mdi mdi-speedometer"></i>
        </span>
        <span class="menu-title">Dashboard</span>
      </a>
    </li>
    <li class="nav-item menu-items">
      <a class="nav-link" data-bs-toggle="collapse" href="#auth" aria-expanded="false" aria-controls="auth">
        <span class="menu-icon">
          <i class="mdi mdi-security"></i>
        </span>
        <span class="menu-title">Administrator</span>
        <i class="menu-arrow"></i>
      </a>
      <div class="collapse" id="auth">
        <ul class="nav flex-column sub-menu">
          <?php 
          // echo request()->segment(2);
          //  $active = '';
          //  if (Request::is(Request::segment(1) . '/' . $uri . '/*') || Request::is(Request::segment(1) . '/' . $uri) || Request::is($uri)) {
          //      $active = 'active';
          //  }
            // $active = '';
            // $getUrl = \Request::path();
            // $url = \Request::route()->getName();
            // echo $url;
            // if($getUrl === $url){
            //   $active = 'active';
            // }

          ?>
          <li class="nav-item"> <a class="nav-link <?php echo e(Request::segment(1)); ?> <?php echo e((Request::segment(1) == 'roles')  ? 'active' : ''); ?>" href="<?php echo e(route('roles.index')); ?>">Roles</a></li>
          <li class="nav-item"> <a class="nav-link <?php echo e(Request::segment(1)); ?> <?php echo e((Request::segment(1) == 'product_type')  ? 'active' : ''); ?>" href="<?php echo e(route('product_type.index')); ?>">Product Type</a></li>
          <li class="nav-item"> <a class="nav-link <?php echo e(Request::segment(1)); ?> <?php echo e((Request::segment(1) == 'product')  ? 'active' : ''); ?>" href="<?php echo e(route('product.index')); ?>">Product</a></li>
          <li class="nav-item"> <a class="nav-link <?php echo e(Request::segment(1)); ?> <?php echo e((Request::segment(1) == 'users')  ? 'active' : ''); ?>" href="<?php echo e(route('users.index')); ?>">Users</a></li>
        </ul>
      </div>
    </li>
  </ul>
</nav><?php /**PATH D:\xampp\htdocs\lls_dev\resources\views/layouts/sidebar.blade.php ENDPATH**/ ?>